# SmartFin - Implementation Plan
## Step-by-Step Guide to Refactor and Build Multi-Platform App

> **Purpose**: Detailed implementation plan with actionable steps, timelines, and deliverables for transforming SmartFin into a multi-platform application with properly segregated architecture.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Prerequisites](#2-prerequisites)
3. [Phase 1: Core Business Logic Extraction](#phase-1-core-business-logic-extraction)
4. [Phase 2: Data Access Layer](#phase-2-data-access-layer)
5. [Phase 3: Service Layer](#phase-3-service-layer)
6. [Phase 4: Web UI Refactoring](#phase-4-web-ui-refactoring)
7. [Phase 5: Mobile App Development](#phase-5-mobile-app-development)
8. [Phase 6: Testing & Quality Assurance](#phase-6-testing--quality-assurance)
9. [Phase 7: Deployment](#phase-7-deployment)
10. [Success Criteria](#10-success-criteria)

---

## 1. Project Overview

### Current State
- Monolithic web application
- ~6600 lines in single `app.js` file
- UI and business logic tightly coupled
- Web-only support

### Target State
- Modular architecture with clear separation of concerns
- Platform-independent business logic
- Support for both web and mobile (iOS/Android)
- 100% feature parity across platforms
- Improved maintainability and testability

### Timeline
**Total Duration**: 12 weeks  
**Team Size**: 2-3 developers  
**Effort**: ~480-720 hours

---

## 2. Prerequisites

### 2.1 Development Environment Setup

#### Required Tools
```bash
# Node.js & npm
node --version  # v18.x or higher
npm --version   # v9.x or higher

# Git
git --version

# Code Editor
# VS Code (recommended) with extensions:
# - ESLint
# - Prettier
# - ES7+ React/Redux/React-Native snippets
```

#### Install Dependencies
```bash
cd smart-personal-finance

# Install existing dependencies
npm install

# Install new development dependencies
npm install --save-dev \
  @babel/core \
  @babel/preset-env \
  jest \
  @testing-library/react \
  @testing-library/jest-dom \
  eslint \
  prettier
```

### 2.2 Project Structure Setup

```bash
# Create new directory structure
mkdir -p src/core/{accounts,budget,investments,goals,insurance,networth,tax,emergency,expenses,dashboard,utils}
mkdir -p src/data/{repositories,firebase,cache}
mkdir -p src/services
mkdir -p src/ui/web/{components,hooks,styles}
mkdir -p src/ui/mobile
mkdir -p src/shared
mkdir -p tests/{core,services,integration}
```

### 2.3 Configuration Files

#### package.json (update)
```json
{
  "name": "smartfin",
  "version": "3.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "test": "jest",
    "test:watch": "jest --watch",
    "lint": "eslint src/",
    "format": "prettier --write src/"
  },
  "dependencies": {
    "firebase": "^10.x.x",
    "chart.js": "^4.x.x",
    "xlsx": "^0.18.x"
  },
  "devDependencies": {
    "@babel/core": "^7.x.x",
    "@babel/preset-env": "^7.x.x",
    "jest": "^29.x.x",
    "@testing-library/react": "^14.x.x",
    "eslint": "^8.x.x",
    "prettier": "^3.x.x",
    "vite": "^5.x.x"
  }
}
```

#### jest.config.js
```javascript
export default {
  testEnvironment: 'jsdom',
  transform: {
    '^.+\\.jsx?$': 'babel-jest',
  },
  moduleNameMapper: {
    '\\.(css|less|scss|sass)$': 'identity-obj-proxy',
  },
  setupFilesAfterEnv: ['<rootDir>/tests/setup.js'],
  collectCoverageFrom: [
    'src/**/*.{js,jsx}',
    '!src/**/*.test.{js,jsx}',
    '!src/ui/**/*',
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80,
    },
  },
};
```

#### .eslintrc.json
```json
{
  "env": {
    "browser": true,
    "es2021": true,
    "node": true,
    "jest": true
  },
  "extends": [
    "eslint:recommended"
  ],
  "parserOptions": {
    "ecmaVersion": "latest",
    "sourceType": "module"
  },
  "rules": {
    "no-console": "warn",
    "no-unused-vars": "warn"
  }
}
```

---

## Phase 1: Core Business Logic Extraction

**Duration**: 2 weeks  
**Effort**: 80 hours

### Week 1: Extract Calculation Modules

#### Day 1-2: Budget Calculator

**File**: `src/core/budget/BudgetCalculator.js`

**Tasks**:
1. ✅ Extract `calculateFixedMonthlyOutflow()` from app.js
2. ✅ Extract `calculateTransferAmount()` from app.js
3. ✅ Extract `calculateVariableExpenditure()` from app.js
4. ✅ Extract `calculateMonthlySummary()` from app.js
5. ✅ Write unit tests

**Code Example**:
```javascript
// src/core/budget/BudgetCalculator.js
export class BudgetCalculator {
  /**
   * Calculate fixed monthly outflow from entries
   * @param {Array} outflowEntries - Outflow entries
   * @returns {number} Total fixed monthly outflow
   */
  static calculateFixedMonthlyOutflow(outflowEntries) {
    return outflowEntries.reduce((total, entry) => {
      // Exclude One-Time frequency
      if (entry.frequency === 'One-Time') return total;
      
      const monthlyAmount = FrequencyConverter.toMonthly(
        entry.amount,
        entry.frequency
      );
      
      return total + monthlyAmount;
    }, 0);
  }

  /**
   * Calculate transfer amount
   * @param {number} primaryIncome
   * @param {number} fixedMonthlyOutflow
   * @returns {number} Transfer amount
   */
  static calculateTransferAmount(primaryIncome, fixedMonthlyOutflow) {
    return primaryIncome - fixedMonthlyOutflow;
  }

  /**
   * Calculate variable expenditure
   * @param {number} totalFunded
   * @param {number} currentBalance
   * @returns {number} Variable expenditure
   */
  static calculateVariableExpenditure(totalFunded, currentBalance) {
    return Math.max(totalFunded - currentBalance, 0);
  }

  /**
   * Calculate monthly budget summary
   * @param {Object} budgetData - Monthly budget data
   * @param {Array} outflowEntries - Outflow entries
   * @returns {Object} Budget summary
   */
  static calculateMonthlySummary(budgetData, outflowEntries) {
    const inflowTotal = this.sumCategoryValues(budgetData.inflow);
    const outflowTotal = this.sumCategoryValues(budgetData.outflow);
    const investingTotal = this.sumCategoryValues(budgetData.investing);
    
    const fixedMonthlyOutflow = this.calculateFixedMonthlyOutflow(outflowEntries);
    const totalSpendable = inflowTotal - fixedMonthlyOutflow;
    const variableExpenses = 
      budgetData.outflow.variableExpenditure + 
      budgetData.outflow.midMonthCCOutstanding;
    const budgetBalance = totalSpendable - variableExpenses;
    
    return {
      inflowTotal,
      outflowTotal,
      investingTotal,
      fixedMonthlyOutflow,
      totalSpendable,
      variableExpenses,
      budgetBalance,
      budgetStatus: this.getBudgetStatus(budgetBalance)
    };
  }

  /**
   * Sum numeric values in a category object
   * @param {Object} category - Category object
   * @returns {number} Sum of numeric values
   */
  static sumCategoryValues(category) {
    return Object.entries(category).reduce((sum, [key, value]) => {
      // Skip description fields
      if (key.endsWith('Desc')) return sum;
      // Only sum numeric values
      if (typeof value === 'number') return sum + value;
      return sum;
    }, 0);
  }

  /**
   * Get budget status based on balance
   * @param {number} balance
   * @returns {Object} Status object
   */
  static getBudgetStatus(balance) {
    if (balance > 0) {
      return {
        type: 'positive',
        message: `Surplus: ₹${balance.toLocaleString('en-IN')}`
      };
    } else if (balance < 0) {
      return {
        type: 'negative',
        message: `Deficit: ₹${Math.abs(balance).toLocaleString('en-IN')}`
      };
    } else {
      return {
        type: 'neutral',
        message: 'Balanced'
      };
    }
  }
}
```

**Test File**: `tests/core/budget/BudgetCalculator.test.js`
```javascript
import { BudgetCalculator } from '../../../src/core/budget/BudgetCalculator.js';

describe('BudgetCalculator', () => {
  describe('calculateFixedMonthlyOutflow', () => {
    it('should calculate monthly outflow correctly', () => {
      const outflows = [
        { amount: 12000, frequency: 'Monthly' },
        { amount: 6000, frequency: 'Quarterly' },
        { amount: 12000, frequency: 'Annual' },
        { amount: 5000, frequency: 'One-Time' } // Should be excluded
      ];
      
      const result = BudgetCalculator.calculateFixedMonthlyOutflow(outflows);
      
      // 12000 + (6000/3) + (12000/12) = 12000 + 2000 + 1000 = 15000
      expect(result).toBe(15000);
    });
  });

  describe('calculateTransferAmount', () => {
    it('should calculate transfer amount correctly', () => {
      const result = BudgetCalculator.calculateTransferAmount(100000, 60000);
      expect(result).toBe(40000);
    });
  });

  describe('calculateVariableExpenditure', () => {
    it('should calculate variable expenditure correctly', () => {
      const result = BudgetCalculator.calculateVariableExpenditure(50000, 30000);
      expect(result).toBe(20000);
    });

    it('should not return negative values', () => {
      const result = BudgetCalculator.calculateVariableExpenditure(30000, 50000);
      expect(result).toBe(0);
    });
  });

  describe('getBudgetStatus', () => {
    it('should return positive status for surplus', () => {
      const result = BudgetCalculator.getBudgetStatus(10000);
      expect(result.type).toBe('positive');
      expect(result.message).toContain('Surplus');
    });

    it('should return negative status for deficit', () => {
      const result = BudgetCalculator.getBudgetStatus(-5000);
      expect(result.type).toBe('negative');
      expect(result.message).toContain('Deficit');
    });

    it('should return neutral status for balanced budget', () => {
      const result = BudgetCalculator.getBudgetStatus(0);
      expect(result.type).toBe('neutral');
      expect(result.message).toBe('Balanced');
    });
  });
});
```

#### Day 3-4: Account, Investment, Goal Calculators

**Files to Create**:
- `src/core/accounts/AccountManager.js`
- `src/core/accounts/AccountValidator.js`
- `src/core/investments/InvestmentCalculator.js`
- `src/core/goals/GoalCalculator.js`

**Tests to Create**:
- `tests/core/accounts/AccountManager.test.js`
- `tests/core/investments/InvestmentCalculator.test.js`
- `tests/core/goals/GoalCalculator.test.js`

#### Day 5: Insurance, Net Worth, Tax Calculators

**Files to Create**:
- `src/core/insurance/InsuranceCalculator.js`
- `src/core/networth/NetWorthCalculator.js`
- `src/core/tax/TaxCalculator.js`

**Tests to Create**:
- `tests/core/insurance/InsuranceCalculator.test.js`
- `tests/core/networth/NetWorthCalculator.test.js`
- `tests/core/tax/TaxCalculator.test.js`

### Week 2: Extract Utility Modules & Validators

#### Day 6-7: Utility Modules

**Files to Create**:
- `src/core/utils/FrequencyConverter.js`
- `src/core/utils/DateUtils.js`
- `src/core/utils/CurrencyFormatter.js`
- `src/core/utils/Validators.js`

**Example**: `src/core/utils/FrequencyConverter.js`
```javascript
export class FrequencyConverter {
  /**
   * Convert any frequency to monthly equivalent
   * @param {number} amount - Amount
   * @param {string} frequency - Frequency
   * @returns {number} Monthly equivalent amount
   */
  static toMonthly(amount, frequency) {
    const divisors = {
      'Monthly': 1,
      'Quarterly': 3,
      'Semi-Annual': 6,
      'Annual': 12,
      'One-Time': 0
    };
    
    const divisor = divisors[frequency];
    if (divisor === undefined) {
      throw new Error(`Invalid frequency: ${frequency}`);
    }
    
    return divisor === 0 ? 0 : amount / divisor;
  }

  /**
   * Convert monthly to any frequency
   * @param {number} monthlyAmount - Monthly amount
   * @param {string} frequency - Target frequency
   * @returns {number} Converted amount
   */
  static fromMonthly(monthlyAmount, frequency) {
    const multipliers = {
      'Monthly': 1,
      'Quarterly': 3,
      'Semi-Annual': 6,
      'Annual': 12
    };
    
    const multiplier = multipliers[frequency];
    if (multiplier === undefined) {
      throw new Error(`Invalid frequency: ${frequency}`);
    }
    
    return monthlyAmount * multiplier;
  }

  /**
   * Get all valid frequencies
   * @returns {Array<string>} List of valid frequencies
   */
  static getValidFrequencies() {
    return ['Monthly', 'Quarterly', 'Semi-Annual', 'Annual', 'One-Time'];
  }
}
```

#### Day 8-9: Validators & Business Rules

**Files to Create**:
- `src/core/budget/BudgetValidator.js`
- `src/core/budget/BudgetRules.js`
- `src/core/accounts/AccountValidator.js`

#### Day 10: Integration & Testing

**Tasks**:
1. ✅ Run all unit tests
2. ✅ Ensure 80%+ code coverage
3. ✅ Fix any failing tests
4. ✅ Document all public methods
5. ✅ Code review

**Deliverables**:
- ✅ All core business logic extracted
- ✅ 100% test coverage for calculators
- ✅ No UI dependencies in core modules
- ✅ Documentation complete

---

## Phase 2: Data Access Layer

**Duration**: 1 week  
**Effort**: 40 hours

### Week 3: Repository Pattern & Data Access

#### Day 11-12: Base Repository

**File**: `src/data/repositories/BaseRepository.js`
```javascript
export class BaseRepository {
  constructor(dataSource) {
    this.dataSource = dataSource;
  }

  async get(id) {
    throw new Error('Method not implemented');
  }

  async save(data) {
    throw new Error('Method not implemented');
  }

  async delete(id) {
    throw new Error('Method not implemented');
  }

  async list() {
    throw new Error('Method not implemented');
  }
}
```

**File**: `src/data/repositories/FirestoreRepository.js`
```javascript
import { BaseRepository } from './BaseRepository.js';

export class FirestoreRepository extends BaseRepository {
  constructor(firestore, collectionName) {
    super('firestore');
    this.db = firestore;
    this.collectionName = collectionName;
  }

  async get(id) {
    try {
      const docRef = this.db.collection(this.collectionName).doc(id);
      const doc = await docRef.get();
      
      if (!doc.exists) {
        return null;
      }
      
      return {
        id: doc.id,
        ...doc.data()
      };
    } catch (error) {
      console.error(`Error getting document ${id}:`, error);
      throw error;
    }
  }

  async save(id, data) {
    try {
      const docRef = this.db.collection(this.collectionName).doc(id);
      await docRef.set(data, { merge: true });
      return { id, ...data };
    } catch (error) {
      console.error(`Error saving document ${id}:`, error);
      throw error;
    }
  }

  async delete(id) {
    try {
      const docRef = this.db.collection(this.collectionName).doc(id);
      await docRef.delete();
    } catch (error) {
      console.error(`Error deleting document ${id}:`, error);
      throw error;
    }
  }

  async listen(id, callback) {
    const docRef = this.db.collection(this.collectionName).doc(id);
    return docRef.onSnapshot(
      (doc) => {
        if (doc.exists) {
          callback({ id: doc.id, ...doc.data() });
        } else {
          callback(null);
        }
      },
      (error) => {
        console.error(`Firestore listener error for ${id}:`, error);
      }
    );
  }
}
```

#### Day 13-14: User Repository & Cache Manager

**File**: `src/data/repositories/UserRepository.js`
**File**: `src/data/cache/CacheManager.js`

#### Day 15: Firebase Configuration

**File**: `src/data/firebase/FirebaseConfig.js`
```javascript
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

// Firebase configuration (from environment variables)
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services
export const db = getFirestore(app);
export const auth = getAuth(app);

export default app;
```

**Deliverables**:
- ✅ Repository pattern implemented
- ✅ Firebase integration working
- ✅ Cache system functional
- ✅ Data layer tests passing

---

## Phase 3: Service Layer

**Duration**: 1 week  
**Effort**: 40 hours

### Week 4: Service Implementation

#### Day 16-17: Core Services

**Files to Create**:
- `src/services/AuthService.js`
- `src/services/AccountService.js`
- `src/services/BudgetService.js`

**Example**: `src/services/AccountService.js`
```javascript
import { AccountManager } from '../core/accounts/AccountManager.js';
import { AccountValidator } from '../core/accounts/AccountValidator.js';

export class AccountService {
  constructor(userRepository, cacheManager) {
    this.userRepository = userRepository;
    this.cache = cacheManager;
  }

  async getAccounts(uid) {
    const cacheKey = `accounts_${uid}`;
    const cached = this.cache.get(cacheKey);
    if (cached) return cached;
    
    const userData = await this.userRepository.getUserData(uid);
    const accounts = userData?.tabData?.cards || [];
    
    this.cache.set(cacheKey, accounts);
    return accounts;
  }

  async addAccount(uid, accountData) {
    // Validate
    const validation = AccountValidator.validateAccount(accountData);
    if (!validation.isValid) {
      return { success: false, errors: validation.errors };
    }
    
    // Get existing accounts
    const accounts = await this.getAccounts(uid);
    
    // Check constraints
    const constraintCheck = AccountManager.validateAccountConstraints(
      accounts,
      accountData
    );
    if (!constraintCheck.isValid) {
      return { success: false, errors: constraintCheck.errors };
    }
    
    // Add account
    const newAccount = {
      id: this.generateId(),
      ...accountData
    };
    accounts.push(newAccount);
    
    // Save
    await this.userRepository.updateTabData(uid, 'cards', accounts);
    this.cache.clearKey(`accounts_${uid}`);
    
    return { success: true, account: newAccount };
  }

  async updateAccount(uid, accountId, updates) {
    const accounts = await this.getAccounts(uid);
    const index = accounts.findIndex(a => a.id === accountId);
    
    if (index === -1) {
      return { success: false, error: 'Account not found' };
    }
    
    // Validate updates
    const updatedAccount = { ...accounts[index], ...updates };
    const validation = AccountValidator.validateAccount(updatedAccount);
    if (!validation.isValid) {
      return { success: false, errors: validation.errors };
    }
    
    accounts[index] = updatedAccount;
    
    await this.userRepository.updateTabData(uid, 'cards', accounts);
    this.cache.clearKey(`accounts_${uid}`);
    
    return { success: true, account: updatedAccount };
  }

  async deleteAccount(uid, accountId) {
    const accounts = await this.getAccounts(uid);
    const filtered = accounts.filter(a => a.id !== accountId);
    
    if (filtered.length === accounts.length) {
      return { success: false, error: 'Account not found' };
    }
    
    await this.userRepository.updateTabData(uid, 'cards', filtered);
    this.cache.clearKey(`accounts_${uid}`);
    
    return { success: true };
  }

  async getPrimaryAccount(uid) {
    const accounts = await this.getAccounts(uid);
    return AccountManager.findPrimaryAccount(accounts);
  }

  async getSalaryAccount(uid) {
    const accounts = await this.getAccounts(uid);
    return AccountManager.findAccountByPurpose(accounts, 'Salary');
  }

  generateId() {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}
```

#### Day 18-19: Additional Services

**Files to Create**:
- `src/services/InvestmentService.js`
- `src/services/GoalService.js`
- `src/services/InsuranceService.js`
- `src/services/NetWorthService.js`
- `src/services/TaxService.js`
- `src/services/ExpenseService.js`

#### Day 20: Dashboard & Export Services

**Files to Create**:
- `src/services/DashboardService.js`
- `src/services/DataExportService.js`

**Deliverables**:
- ✅ All services implemented
- ✅ Service tests passing
- ✅ API documentation complete

---

## Phase 4: Web UI Refactoring

**Duration**: 2 weeks  
**Effort**: 80 hours

### Week 5-6: Refactor Web UI

#### Day 21-25: Component Refactoring

**Tasks**:
1. ✅ Create component structure
2. ✅ Refactor Dashboard components
3. ✅ Refactor Account components
4. ✅ Refactor Budget components
5. ✅ Refactor Investment components

**Example**: Refactored Dashboard

**Before** (in app.js):
```javascript
function renderDashboard() {
  const html = `
    <div class="dashboard-grid">
      <!-- Inline HTML with mixed logic -->
    </div>
  `;
  document.getElementById('dashboardPanel').innerHTML = html;
  
  // Business logic mixed with UI
  const accounts = getAccounts();
  const totalBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);
  // ... more calculations
}
```

**After** (using services):
```javascript
// src/ui/web/components/dashboard/DashboardView.js
import { DashboardService } from '../../../../services/DashboardService.js';
import { ThisMonthCard } from './ThisMonthCard.js';
import { AccountsCard } from './AccountsCard.js';

export class DashboardView {
  constructor(dashboardService) {
    this.service = dashboardService;
    this.container = document.getElementById('dashboardPanel');
  }

  async render(uid, currentMonth) {
    try {
      // Get data from service (no business logic here)
      const metrics = await this.service.getDashboardMetrics(uid, currentMonth);
      
      // Render UI
      this.container.innerHTML = `
        <div class="dashboard-grid">
          <div id="thisMonthCard"></div>
          <div id="accountsCard"></div>
          <div id="goalsCard"></div>
          <div id="preparednessCard"></div>
        </div>
      `;
      
      // Render sub-components
      new ThisMonthCard(metrics.thisMonth).render('thisMonthCard');
      new AccountsCard(metrics.accountsNetWorth).render('accountsCard');
      // ... more components
    } catch (error) {
      this.renderError(error);
    }
  }

  renderError(error) {
    this.container.innerHTML = `
      <div class="error-message">
        <p>Failed to load dashboard: ${error.message}</p>
      </div>
    `;
  }
}
```

#### Day 26-30: Forms, Tables, Charts

**Tasks**:
1. ✅ Refactor all forms to use services
2. ✅ Refactor tables with proper event handling
3. ✅ Update chart rendering
4. ✅ Implement responsive design improvements
5. ✅ Test on multiple browsers

**Deliverables**:
- ✅ Web UI fully refactored
- ✅ All features working
- ✅ No business logic in UI components
- ✅ Responsive design verified

---

## Phase 5: Mobile App Development

**Duration**: 4 weeks  
**Effort**: 160 hours

### Week 7: Mobile Project Setup

#### Day 31-35: React Native Setup

**Tasks**:
1. ✅ Initialize React Native project
2. ✅ Set up navigation
3. ✅ Configure Firebase for mobile
4. ✅ Set up shared services
5. ✅ Create base components

**Commands**:
```bash
# Create React Native project
npx react-native init SmartFinMobile --template react-native-template-typescript

cd SmartFinMobile

# Install dependencies
npm install @react-navigation/native @react-navigation/bottom-tabs
npm install react-native-screens react-native-safe-area-context
npm install @react-native-firebase/app @react-native-firebase/auth @react-native-firebase/firestore
npm install react-native-chart-kit
npm install react-native-svg

# Link services from main project
ln -s ../../src/core ./src/core
ln -s ../../src/data ./src/data
ln -s ../../src/services ./src/services
```

### Week 8-9: Mobile UI Implementation

#### Day 36-45: Screen Development

**Tasks**:
1. ✅ Dashboard screen
2. ✅ Accounts screen
3. ✅ Budget screen
4. ✅ Investments screen
5. ✅ Goals screen
6. ✅ Insurance screen
7. ✅ Net Worth screen
8. ✅ Expenses screen
9. ✅ Settings screen
10. ✅ Navigation setup

**Example**: Dashboard Screen
```jsx
// src/ui/mobile/screens/DashboardScreen.js
import React, { useEffect, useState } from 'react';
import {
  View,
  ScrollView,
  RefreshControl,
  StyleSheet,
  ActivityIndicator
} from 'react-native';
import { DashboardService } from '../../../services/DashboardService';
import { ThisMonthCard } from '../components/dashboard/ThisMonthCard';
import { AccountsCard } from '../components/dashboard/AccountsCard';

export const DashboardScreen = ({ navigation }) => {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const dashboardService = new DashboardService(/* dependencies */);
      const uid = getCurrentUserId();
      const data = await dashboardService.getDashboardMetrics(uid, getCurrentMonth());
      setMetrics(data);
    } catch (error) {
      console.error('Failed to load dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboard();
    setRefreshing(false);
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#7c3aed" />
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          tintColor="#7c3aed"
        />
      }
    >
      <ThisMonthCard data={metrics?.thisMonth} />
      <AccountsCard data={metrics?.accountsNetWorth} />
      {/* More cards */}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  content: {
    padding: 16,
  },
  centered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
```

### Week 10: Mobile Polish & Testing

#### Day 46-50: Platform-Specific Features

**Tasks**:
1. ✅ Implement touch gestures
2. ✅ Add biometric authentication
3. ✅ Implement push notifications
4. ✅ Add offline support
5. ✅ Performance optimization

**Deliverables**:
- ✅ Mobile app fully functional
- ✅ Feature parity with web
- ✅ Platform-specific features implemented

---

## Phase 6: Testing & Quality Assurance

**Duration**: 2 weeks  
**Effort**: 80 hours

### Week 11: Comprehensive Testing

#### Day 51-55: Testing

**Tasks**:
1. ✅ Unit tests (core & services)
2. ✅ Integration tests
3. ✅ E2E tests (web)
4. ✅ E2E tests (mobile)
5. ✅ Performance testing

**Test Coverage Goals**:
- Core business logic: 100%
- Services: 90%
- UI components: 70%
- Overall: 85%

### Week 12: Bug Fixes & Documentation

#### Day 56-60: Final Polish

**Tasks**:
1. ✅ Fix all critical bugs
2. ✅ Update documentation
3. ✅ Create user manual
4. ✅ Record demo videos
5. ✅ Prepare release notes

**Deliverables**:
- ✅ All tests passing
- ✅ Zero critical bugs
- ✅ Documentation complete

---

## Phase 7: Deployment

**Duration**: 1 week  
**Effort**: 40 hours

### Week 13: Production Deployment

#### Day 61-65: Deployment

**Web Deployment**:
```bash
# Build for production
npm run build

# Deploy to hosting (e.g., Vercel, Netlify)
vercel --prod
```

**Mobile Deployment**:
```bash
# iOS
cd ios
pod install
cd ..
npx react-native run-ios --configuration Release

# Android
cd android
./gradlew assembleRelease
```

**Tasks**:
1. ✅ Deploy web app to production
2. ✅ Submit iOS app to App Store
3. ✅ Submit Android app to Play Store
4. ✅ Set up monitoring & analytics
5. ✅ Create rollback plan

---

## 10. Success Criteria

### Functional Requirements
- ✅ All existing features work on web
- ✅ All existing features work on mobile
- ✅ 100% feature parity across platforms
- ✅ Data syncs correctly across devices
- ✅ No data loss during migration

### Technical Requirements
- ✅ Business logic is platform-independent
- ✅ 85%+ test coverage
- ✅ No UI code in business logic
- ✅ No business logic in UI code
- ✅ Clean separation of concerns

### Performance Requirements
- ✅ Web: Page load < 3s on 3G
- ✅ Mobile: App launch < 2s
- ✅ All interactions < 100ms response time
- ✅ Smooth 60fps animations

### Quality Requirements
- ✅ Zero critical bugs
- ✅ Accessibility compliance (WCAG 2.1 AA)
- ✅ Security audit passed
- ✅ Code review completed

---

## Appendix A: File Checklist

### Core Business Logic (src/core/)
- [ ] accounts/AccountManager.js
- [ ] accounts/AccountValidator.js
- [ ] budget/BudgetCalculator.js
- [ ] budget/BudgetValidator.js
- [ ] budget/BudgetRules.js
- [ ] investments/InvestmentCalculator.js
- [ ] goals/GoalCalculator.js
- [ ] insurance/InsuranceCalculator.js
- [ ] networth/NetWorthCalculator.js
- [ ] tax/TaxCalculator.js
- [ ] emergency/EmergencyFundCalculator.js
- [ ] expenses/ExpenseAnalyzer.js
- [ ] dashboard/DashboardAggregator.js
- [ ] utils/FrequencyConverter.js
- [ ] utils/DateUtils.js
- [ ] utils/CurrencyFormatter.js
- [ ] utils/Validators.js

### Data Access Layer (src/data/)
- [ ] repositories/BaseRepository.js
- [ ] repositories/FirestoreRepository.js
- [ ] repositories/UserRepository.js
- [ ] firebase/FirebaseConfig.js
- [ ] firebase/FirebaseAuth.js
- [ ] cache/CacheManager.js

### Service Layer (src/services/)
- [ ] AuthService.js
- [ ] AccountService.js
- [ ] BudgetService.js
- [ ] InvestmentService.js
- [ ] GoalService.js
- [ ] InsuranceService.js
- [ ] NetWorthService.js
- [ ] TaxService.js
- [ ] ExpenseService.js
- [ ] DashboardService.js
- [ ] DataExportService.js

### Web UI (src/ui/web/)
- [ ] components/common/Button.js
- [ ] components/common/Card.js
- [ ] components/common/Input.js
- [ ] components/common/Modal.js
- [ ] components/dashboard/DashboardView.js
- [ ] components/accounts/AccountsView.js
- [ ] components/budget/BudgetView.js
- [ ] [... more components]

### Mobile UI (src/ui/mobile/)
- [ ] screens/DashboardScreen.js
- [ ] screens/AccountsScreen.js
- [ ] screens/BudgetScreen.js
- [ ] [... more screens]

### Tests (tests/)
- [ ] core/budget/BudgetCalculator.test.js
- [ ] core/accounts/AccountManager.test.js
- [ ] [... more tests]

---

*Document Version: 1.0*  
*Last Updated: 2026-08-13*  
*Author: SmartFin Development Team*
