# SmartFin - UI Component Guide
## Web & Mobile Component Design

> **Purpose**: Comprehensive guide for building UI components for both web and mobile platforms with consistent design patterns and responsive behavior.

---

## Table of Contents

1. [Design System](#1-design-system)
2. [Common Components](#2-common-components)
3. [Web Components](#3-web-components)
4. [Mobile Components](#4-mobile-components)
5. [Responsive Design Patterns](#5-responsive-design-patterns)
6. [Component Examples](#6-component-examples)
7. [Styling Guidelines](#7-styling-guidelines)
8. [Accessibility](#8-accessibility)

---

## 1. Design System

### 1.1 Color Palette

#### Light Theme
```css
:root, [data-theme="light"] {
  /* Background */
  --bg: #f8f9fa;
  --surf1: #ffffff;
  --surf2: #f1f3f5;
  
  /* Text */
  --text: #212529;
  --dim: #495057;
  --muted: #868e96;
  
  /* Borders */
  --border: #dee2e6;
  --border2: #e9ecef;
  
  /* Accent */
  --accent: #7c3aed;
  --accent-hover: #6d28d9;
  --accent-light: #ede9fe;
  
  /* Status Colors */
  --success: #10b981;
  --success-bg: #d1fae5;
  --warning: #f59e0b;
  --warning-bg: #fef3c7;
  --error: #ef4444;
  --error-bg: #fee2e2;
  --info: #3b82f6;
  --info-bg: #dbeafe;
  
  /* Shadows */
  --shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.15);
}
```

#### Dark Theme
```css
[data-theme="dark"] {
  /* Background */
  --bg: #0b1020;
  --surf1: #151b2e;
  --surf2: #1e2538;
  
  /* Text */
  --text: #e2e8f0;
  --dim: #cbd5e1;
  --muted: #94a3b8;
  
  /* Borders */
  --border: #2d3748;
  --border2: #374151;
  
  /* Accent */
  --accent: #8b5cf6;
  --accent-hover: #7c3aed;
  --accent-light: #2e1065;
  
  /* Status Colors */
  --success: #34d399;
  --success-bg: #064e3b;
  --warning: #fbbf24;
  --warning-bg: #78350f;
  --error: #f87171;
  --error-bg: #7f1d1d;
  --info: #60a5fa;
  --info-bg: #1e3a8a;
  
  /* Shadows */
  --shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
  --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.5);
}
```

### 1.2 Typography

```css
/* Font Family */
--font-primary: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
--font-display: 'Plus Jakarta Sans', var(--font-primary);

/* Font Sizes */
--text-xs: 0.75rem;    /* 12px */
--text-sm: 0.875rem;   /* 14px */
--text-base: 1rem;     /* 16px */
--text-lg: 1.125rem;   /* 18px */
--text-xl: 1.25rem;    /* 20px */
--text-2xl: 1.5rem;    /* 24px */
--text-3xl: 1.875rem;  /* 30px */
--text-4xl: 2.25rem;   /* 36px */

/* Font Weights */
--font-light: 300;
--font-normal: 400;
--font-medium: 500;
--font-semibold: 600;
--font-bold: 700;

/* Line Heights */
--leading-tight: 1.25;
--leading-normal: 1.5;
--leading-relaxed: 1.75;
```

### 1.3 Spacing

```css
/* Spacing Scale (based on 4px) */
--space-1: 0.25rem;   /* 4px */
--space-2: 0.5rem;    /* 8px */
--space-3: 0.75rem;   /* 12px */
--space-4: 1rem;      /* 16px */
--space-5: 1.25rem;   /* 20px */
--space-6: 1.5rem;    /* 24px */
--space-8: 2rem;      /* 32px */
--space-10: 2.5rem;   /* 40px */
--space-12: 3rem;     /* 48px */
--space-16: 4rem;     /* 64px */
```

### 1.4 Border Radius

```css
--radius-sm: 0.375rem;   /* 6px */
--radius-md: 0.5rem;     /* 8px */
--radius-lg: 0.75rem;    /* 12px */
--radius-xl: 1rem;       /* 16px */
--radius-full: 9999px;   /* Fully rounded */
```

### 1.5 Breakpoints

```css
/* Mobile First Approach */
--mobile: 320px;
--tablet: 768px;
--desktop: 1025px;
--wide: 1440px;
```

---

## 2. Common Components

### 2.1 Button Component

#### Web (React)
```jsx
// Button.jsx
import React from 'react';
import './Button.css';

export const Button = ({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  disabled = false,
  loading = false,
  onClick,
  type = 'button',
  ...props
}) => {
  const classNames = [
    'btn',
    `btn-${variant}`,
    `btn-${size}`,
    fullWidth && 'btn-full',
    loading && 'btn-loading',
    disabled && 'btn-disabled'
  ].filter(Boolean).join(' ');

  return (
    <button
      type={type}
      className={classNames}
      onClick={onClick}
      disabled={disabled || loading}
      {...props}
    >
      {loading && <span className="btn-spinner"></span>}
      {children}
    </button>
  );
};
```

#### Button Styles
```css
/* Button.css */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  font-family: var(--font-primary);
  font-weight: var(--font-medium);
  border-radius: var(--radius-md);
  transition: all 0.2s ease;
  cursor: pointer;
  border: none;
  outline: none;
}

/* Sizes */
.btn-sm {
  padding: var(--space-2) var(--space-3);
  font-size: var(--text-sm);
  min-height: 32px;
}

.btn-md {
  padding: var(--space-3) var(--space-4);
  font-size: var(--text-base);
  min-height: 40px;
}

.btn-lg {
  padding: var(--space-4) var(--space-6);
  font-size: var(--text-lg);
  min-height: 48px;
}

/* Variants */
.btn-primary {
  background: var(--accent);
  color: white;
}

.btn-primary:hover:not(:disabled) {
  background: var(--accent-hover);
  transform: translateY(-1px);
  box-shadow: var(--shadow);
}

.btn-secondary {
  background: var(--surf2);
  color: var(--text);
  border: 1px solid var(--border);
}

.btn-secondary:hover:not(:disabled) {
  background: var(--surf1);
  border-color: var(--accent);
}

.btn-ghost {
  background: transparent;
  color: var(--accent);
}

.btn-ghost:hover:not(:disabled) {
  background: var(--accent-light);
}

.btn-danger {
  background: var(--error);
  color: white;
}

.btn-danger:hover:not(:disabled) {
  background: #dc2626;
}

/* States */
.btn-full {
  width: 100%;
}

.btn:disabled,
.btn-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-loading {
  position: relative;
  color: transparent;
}

.btn-spinner {
  position: absolute;
  width: 16px;
  height: 16px;
  border: 2px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

/* Mobile Touch Targets */
@media (max-width: 767px) {
  .btn {
    min-height: 44px;
    min-width: 44px;
  }
}
```

#### Mobile (React Native)
```jsx
// Button.js
import React from 'react';
import {
  TouchableOpacity,
  Text,
  ActivityIndicator,
  StyleSheet
} from 'react-native';

export const Button = ({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  disabled = false,
  loading = false,
  onPress,
  ...props
}) => {
  const buttonStyles = [
    styles.btn,
    styles[`btn${variant.charAt(0).toUpperCase() + variant.slice(1)}`],
    styles[`btn${size.charAt(0).toUpperCase() + size.slice(1)}`],
    fullWidth && styles.btnFull,
    disabled && styles.btnDisabled
  ];

  const textStyles = [
    styles.btnText,
    styles[`btnText${variant.charAt(0).toUpperCase() + variant.slice(1)}`]
  ];

  return (
    <TouchableOpacity
      style={buttonStyles}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.7}
      {...props}
    >
      {loading ? (
        <ActivityIndicator color="#fff" />
      ) : (
        <Text style={textStyles}>{children}</Text>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  btn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 8,
    minHeight: 44,
  },
  btnSm: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    minHeight: 36,
  },
  btnMd: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    minHeight: 44,
  },
  btnLg: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    minHeight: 52,
  },
  btnPrimary: {
    backgroundColor: '#7c3aed',
  },
  btnSecondary: {
    backgroundColor: '#f1f3f5',
    borderWidth: 1,
    borderColor: '#dee2e6',
  },
  btnDanger: {
    backgroundColor: '#ef4444',
  },
  btnFull: {
    width: '100%',
  },
  btnDisabled: {
    opacity: 0.5,
  },
  btnText: {
    fontSize: 16,
    fontWeight: '500',
  },
  btnTextPrimary: {
    color: '#ffffff',
  },
  btnTextSecondary: {
    color: '#212529',
  },
  btnTextDanger: {
    color: '#ffffff',
  },
});
```

### 2.2 Card Component

#### Web (React)
```jsx
// Card.jsx
import React from 'react';
import './Card.css';

export const Card = ({
  children,
  title,
  subtitle,
  actions,
  padding = 'md',
  hoverable = false,
  onClick,
  ...props
}) => {
  const classNames = [
    'card',
    `card-padding-${padding}`,
    hoverable && 'card-hoverable',
    onClick && 'card-clickable'
  ].filter(Boolean).join(' ');

  return (
    <div className={classNames} onClick={onClick} {...props}>
      {(title || subtitle || actions) && (
        <div className="card-header">
          <div className="card-header-content">
            {title && <h3 className="card-title">{title}</h3>}
            {subtitle && <p className="card-subtitle">{subtitle}</p>}
          </div>
          {actions && <div className="card-actions">{actions}</div>}
        </div>
      )}
      <div className="card-body">{children}</div>
    </div>
  );
};
```

#### Card Styles
```css
/* Card.css */
.card {
  background: var(--surf1);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow);
  transition: all 0.2s ease;
}

.card-padding-sm {
  padding: var(--space-3);
}

.card-padding-md {
  padding: var(--space-4);
}

.card-padding-lg {
  padding: var(--space-6);
}

.card-hoverable:hover {
  box-shadow: var(--shadow-lg);
  transform: translateY(-2px);
}

.card-clickable {
  cursor: pointer;
}

.card-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: var(--space-4);
}

.card-title {
  font-size: var(--text-lg);
  font-weight: var(--font-semibold);
  color: var(--text);
  margin: 0;
}

.card-subtitle {
  font-size: var(--text-sm);
  color: var(--muted);
  margin: var(--space-1) 0 0 0;
}

.card-body {
  color: var(--text);
}

/* Mobile */
@media (max-width: 767px) {
  .card {
    border-radius: var(--radius-md);
  }
  
  .card-padding-md {
    padding: var(--space-3);
  }
  
  .card-padding-lg {
    padding: var(--space-4);
  }
}
```

#### Mobile (React Native)
```jsx
// Card.js
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export const Card = ({
  children,
  title,
  subtitle,
  actions,
  padding = 'md',
  onPress,
  ...props
}) => {
  const Container = onPress ? TouchableOpacity : View;
  
  const paddingStyles = {
    sm: styles.paddingSm,
    md: styles.paddingMd,
    lg: styles.paddingLg,
  };

  return (
    <Container
      style={[styles.card, paddingStyles[padding]]}
      onPress={onPress}
      activeOpacity={onPress ? 0.7 : 1}
      {...props}
    >
      {(title || subtitle || actions) && (
        <View style={styles.header}>
          <View style={styles.headerContent}>
            {title && <Text style={styles.title}>{title}</Text>}
            {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
          </View>
          {actions && <View style={styles.actions}>{actions}</View>}
        </View>
      )}
      <View style={styles.body}>{children}</View>
    </Container>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  paddingSm: {
    padding: 12,
  },
  paddingMd: {
    padding: 16,
  },
  paddingLg: {
    padding: 24,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  headerContent: {
    flex: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#212529',
  },
  subtitle: {
    fontSize: 14,
    color: '#868e96',
    marginTop: 4,
  },
  actions: {
    marginLeft: 12,
  },
  body: {
    // Content styles
  },
});
```

### 2.3 Input Component

#### Web (React)
```jsx
// Input.jsx
import React, { useState } from 'react';
import './Input.css';

export const Input = ({
  label,
  type = 'text',
  value,
  onChange,
  placeholder,
  error,
  hint,
  required = false,
  disabled = false,
  prefix,
  suffix,
  ...props
}) => {
  const [focused, setFocused] = useState(false);

  const containerClasses = [
    'input-container',
    focused && 'input-focused',
    error && 'input-error',
    disabled && 'input-disabled'
  ].filter(Boolean).join(' ');

  return (
    <div className="input-wrapper">
      {label && (
        <label className="input-label">
          {label}
          {required && <span className="input-required">*</span>}
        </label>
      )}
      <div className={containerClasses}>
        {prefix && <span className="input-prefix">{prefix}</span>}
        <input
          type={type}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          disabled={disabled}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          className="input-field"
          {...props}
        />
        {suffix && <span className="input-suffix">{suffix}</span>}
      </div>
      {error && <span className="input-error-text">{error}</span>}
      {hint && !error && <span className="input-hint">{hint}</span>}
    </div>
  );
};
```

#### Input Styles
```css
/* Input.css */
.input-wrapper {
  margin-bottom: var(--space-4);
}

.input-label {
  display: block;
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
  color: var(--text);
  margin-bottom: var(--space-2);
}

.input-required {
  color: var(--error);
  margin-left: var(--space-1);
}

.input-container {
  display: flex;
  align-items: center;
  background: var(--surf1);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  transition: all 0.2s ease;
}

.input-container:hover:not(.input-disabled) {
  border-color: var(--accent);
}

.input-focused {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-light);
}

.input-error {
  border-color: var(--error);
}

.input-error.input-focused {
  box-shadow: 0 0 0 3px var(--error-bg);
}

.input-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.input-field {
  flex: 1;
  padding: var(--space-3) var(--space-4);
  font-size: var(--text-base);
  color: var(--text);
  background: transparent;
  border: none;
  outline: none;
  min-height: 44px;
}

.input-field::placeholder {
  color: var(--muted);
}

.input-prefix,
.input-suffix {
  padding: 0 var(--space-3);
  font-size: var(--text-sm);
  color: var(--muted);
}

.input-error-text {
  display: block;
  margin-top: var(--space-2);
  font-size: var(--text-sm);
  color: var(--error);
}

.input-hint {
  display: block;
  margin-top: var(--space-2);
  font-size: var(--text-sm);
  color: var(--muted);
}

/* Mobile */
@media (max-width: 767px) {
  .input-field {
    font-size: 16px; /* Prevent zoom on iOS */
  }
}
```

### 2.4 Modal Component

#### Web (React)
```jsx
// Modal.jsx
import React, { useEffect } from 'react';
import ReactDOM from 'react-dom';
import './Modal.css';

export const Modal = ({
  isOpen,
  onClose,
  title,
  children,
  footer,
  size = 'md',
  closeOnOverlayClick = true,
  showCloseButton = true
}) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const modalContent = (
    <div className="modal-overlay" onClick={closeOnOverlayClick ? onClose : undefined}>
      <div
        className={`modal-content modal-${size}`}
        onClick={(e) => e.stopPropagation()}
      >
        {(title || showCloseButton) && (
          <div className="modal-header">
            {title && <h2 className="modal-title">{title}</h2>}
            {showCloseButton && (
              <button className="modal-close" onClick={onClose}>
                ×
              </button>
            )}
          </div>
        )}
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  );

  return ReactDOM.createPortal(modalContent, document.body);
};
```

#### Modal Styles
```css
/* Modal.css */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: var(--space-4);
  animation: fadeIn 0.2s ease;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.modal-content {
  background: var(--surf1);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-lg);
  max-height: 90vh;
  overflow-y: auto;
  animation: slideUp 0.3s ease;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.modal-sm {
  width: 100%;
  max-width: 400px;
}

.modal-md {
  width: 100%;
  max-width: 600px;
}

.modal-lg {
  width: 100%;
  max-width: 800px;
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-6);
  border-bottom: 1px solid var(--border);
}

.modal-title {
  font-size: var(--text-xl);
  font-weight: var(--font-semibold);
  color: var(--text);
  margin: 0;
}

.modal-close {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  border: none;
  border-radius: var(--radius-md);
  font-size: 24px;
  color: var(--muted);
  cursor: pointer;
  transition: all 0.2s ease;
}

.modal-close:hover {
  background: var(--surf2);
  color: var(--text);
}

.modal-body {
  padding: var(--space-6);
}

.modal-footer {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: var(--space-3);
  padding: var(--space-6);
  border-top: 1px solid var(--border);
}

/* Mobile */
@media (max-width: 767px) {
  .modal-overlay {
    padding: 0;
    align-items: flex-end;
  }
  
  .modal-content {
    width: 100%;
    max-width: 100%;
    max-height: 95vh;
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }
  
  .modal-header,
  .modal-body,
  .modal-footer {
    padding: var(--space-4);
  }
}
```

---

## 3. Web Components

### 3.1 Dashboard Components

#### ThisMonthCard.jsx
```jsx
import React from 'react';
import { Card } from '../common/Card';
import { CurrencyFormatter } from '../../../core/utils/CurrencyFormatter';
import './DashboardCards.css';

export const ThisMonthCard = ({ data }) => {
  if (!data) return null;

  return (
    <Card title="This Month" className="dashboard-card">
      <div className="metric-list">
        <div className="metric-row">
          <span className="metric-label">Usable Income</span>
          <span className="metric-value">
            {CurrencyFormatter.format(data.usableIncome)}
          </span>
        </div>
        
        <div className="metric-row">
          <span className="metric-label">Recurring Commitments</span>
          <span className="metric-value">
            {CurrencyFormatter.format(data.recurringCommitments)}
          </span>
        </div>
        
        <div className="metric-row highlight">
          <span className="metric-label">Available After Commitments</span>
          <span className="metric-value primary">
            {CurrencyFormatter.format(data.availableAfterCommitments)}
          </span>
        </div>
        
        <div className="metric-row">
          <span className="metric-label">Credit Card Usage</span>
          <span className="metric-value">
            {CurrencyFormatter.format(data.creditCardUsage)}
          </span>
        </div>
        
        <div className="metric-row">
          <span className="metric-label">Expenditure Balance</span>
          <span className="metric-value">
            {CurrencyFormatter.format(data.expenditureBalance)}
          </span>
        </div>
      </div>
      
      <div className={`budget-status budget-status-${data.budgetStatus.type}`}>
        <span className="budget-status-icon">
          {data.budgetStatus.type === 'positive' ? '✓' : '!'}
        </span>
        <span className="budget-status-message">
          {data.budgetStatus.message}
        </span>
      </div>
      
      {!data.accountStatus.hasPrimary && (
        <div className="alert alert-warning">
          <strong>Setup Required:</strong> Please add a Primary account
        </div>
      )}
    </Card>
  );
};
```

#### DashboardCards.css
```css
.dashboard-card {
  height: 100%;
}

.metric-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
}

.metric-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-2) 0;
}

.metric-row.highlight {
  padding: var(--space-3);
  background: var(--surf2);
  border-radius: var(--radius-md);
  margin: var(--space-2) 0;
}

.metric-label {
  font-size: var(--text-sm);
  color: var(--dim);
}

.metric-value {
  font-size: var(--text-base);
  font-weight: var(--font-semibold);
  color: var(--text);
}

.metric-value.primary {
  font-size: var(--text-lg);
  color: var(--accent);
}

.budget-status {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-3);
  border-radius: var(--radius-md);
  margin-top: var(--space-4);
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
}

.budget-status-positive {
  background: var(--success-bg);
  color: var(--success);
}

.budget-status-negative {
  background: var(--error-bg);
  color: var(--error);
}

.budget-status-neutral {
  background: var(--info-bg);
  color: var(--info);
}

.alert {
  padding: var(--space-3);
  border-radius: var(--radius-md);
  margin-top: var(--space-4);
  font-size: var(--text-sm);
}

.alert-warning {
  background: var(--warning-bg);
  color: var(--warning);
}
```

---

## 4. Mobile Components

### 4.1 Dashboard Screen

```jsx
// DashboardScreen.js
import React, { useEffect, useState } from 'react';
import {
  View,
  ScrollView,
  RefreshControl,
  StyleSheet,
  Text
} from 'react-native';
import { useDashboard } from '../hooks/useDashboard';
import { ThisMonthCard } from '../components/dashboard/ThisMonthCard';
import { AccountsCard } from '../components/dashboard/AccountsCard';
import { GoalsCard } from '../components/dashboard/GoalsCard';
import { PreparednessCard } from '../components/dashboard/PreparednessCard';

export const DashboardScreen = ({ navigation }) => {
  const { metrics, loading, error, refresh } = useDashboard();
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = async () => {
    setRefreshing(true);
    await refresh();
    setRefreshing(false);
  };

  if (loading && !metrics) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#7c3aed" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.centered}>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          tintColor="#7c3aed"
        />
      }
    >
      <ThisMonthCard data={metrics?.thisMonth} />
      <AccountsCard data={metrics?.accountsNetWorth} />
      <GoalsCard data={metrics?.goalsInvestments} />
      <PreparednessCard data={metrics?.preparedness} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  content: {
    padding: 16,
    gap: 16,
  },
  centered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  errorText: {
    fontSize: 16,
    color: '#ef4444',
    textAlign: 'center',
  },
});
```

---

## 5. Responsive Design Patterns

### 5.1 Grid Layout

```css
/* Responsive Grid */
.dashboard-grid {
  display: grid;
  gap: var(--space-4);
}

/* Mobile: 1 column */
@media (max-width: 767px) {
  .dashboard-grid {
    grid-template-columns: 1fr;
  }
}

/* Tablet: 2 columns */
@media (min-width: 768px) and (max-width: 1024px) {
  .dashboard-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

/* Desktop: 2 columns */
@media (min-width: 1025px) {
  .dashboard-grid {
    grid-template-columns: repeat(2, 1fr);
    gap: var(--space-6);
  }
}
```

### 5.2 Responsive Typography

```css
/* Fluid Typography */
.heading-1 {
  font-size: clamp(1.5rem, 4vw, 2.25rem);
}

.heading-2 {
  font-size: clamp(1.25rem, 3vw, 1.875rem);
}

.heading-3 {
  font-size: clamp(1.125rem, 2.5vw, 1.5rem);
}
```

### 5.3 Touch-Friendly Targets

```css
/* Ensure minimum 44x44px touch targets on mobile */
@media (max-width: 767px) {
  button,
  a,
  .clickable {
    min-height: 44px;
    min-width: 44px;
  }
  
  /* Increase spacing between interactive elements */
  .button-group {
    gap: var(--space-3);
  }
}
```

---

## 6. Component Examples

### 6.1 Account Card (Web)

```jsx
// AccountCard.jsx
import React from 'react';
import { Card } from '../common/Card';
import { CurrencyFormatter } from '../../../core/utils/CurrencyFormatter';
import './AccountCard.css';

export const AccountCard = ({ account, onEdit, onDelete }) => {
  const getBadgeColor = (purpose) => {
    const colors = {
      'Salary': 'blue',
      'Expenditure': 'green',
      'Saving': 'purple',
      'Investment': 'orange',
      'Loan': 'red',
      'Others': 'gray'
    };
    return colors[purpose] || 'gray';
  };

  return (
    <Card className="account-card">
      <div className="account-header">
        <div>
          <h3 className="account-name">{account.bankName}</h3>
          <div className="account-badges">
            {account.isPrimary === 'Yes' && (
              <span className="badge badge-primary">Primary</span>
            )}
            <span className={`badge badge-${getBadgeColor(account.purpose)}`}>
              {account.purpose}
            </span>
          </div>
        </div>
        <div className="account-balance">
          {CurrencyFormatter.format(account.balance)}
        </div>
      </div>
      
      <div className="account-details">
        {account.creditCardPresent === 'Yes' && (
          <div className="account-detail-row">
            <span className="detail-label">Credit Limit</span>
            <span className="detail-value">
              {CurrencyFormatter.format(account.creditCardLimit)}
            </span>
          </div>
        )}
      </div>
      
      <div className="account-actions">
        <button className="btn btn-sm btn-ghost" onClick={() => onEdit(account)}>
          Edit
        </button>
        <button className="btn btn-sm btn-ghost btn-danger" onClick={() => onDelete(account.id)}>
          Delete
        </button>
      </div>
    </Card>
  );
};
```

### 6.2 Goal Progress (Mobile)

```jsx
// GoalProgress.js
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { ProgressBar } from '../common/ProgressBar';
import { CurrencyFormatter } from '../../../core/utils/CurrencyFormatter';

export const GoalProgress = ({ goal }) => {
  const progress = (goal.amountAccumulated / goal.amountNeeded) * 100;
  const remaining = goal.amountNeeded - goal.amountAccumulated;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.name}>{goal.name}</Text>
        <Text style={styles.progress}>{Math.round(progress)}%</Text>
      </View>
      
      <ProgressBar progress={progress} color="#7c3aed" />
      
      <View style={styles.details}>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Accumulated</Text>
          <Text style={styles.detailValue}>
            {CurrencyFormatter.format(goal.amountAccumulated)}
          </Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Remaining</Text>
          <Text style={styles.detailValue}>
            {CurrencyFormatter.format(remaining)}
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    marginBottom: 12,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
    color: '#212529',
    flex: 1,
  },
  progress: {
    fontSize: 16,
    fontWeight: '600',
    color: '#7c3aed',
  },
  details: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  detailItem: {
    flex: 1,
  },
  detailLabel: {
    fontSize: 12,
    color: '#868e96',
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '500',
    color: '#212529',
  },
});
```

---

## 7. Styling Guidelines

### 7.1 CSS Best Practices

1. **Use CSS Variables** for theming
2. **Mobile-First** approach
3. **BEM Naming** convention
4. **Avoid !important**
5. **Use Flexbox/Grid** for layouts

### 7.2 React Native Best Practices

1. **StyleSheet.create** for performance
2. **Consistent spacing** using multiples of 4
3. **Platform-specific** styles when needed
4. **Avoid inline styles**
5. **Use Dimensions** API for responsive sizing

---

## 8. Accessibility

### 8.1 Web Accessibility

```jsx
// Accessible Button
<button
  aria-label="Delete account"
  aria-describedby="delete-warning"
  onClick={handleDelete}
>
  Delete
</button>
<span id="delete-warning" className="sr-only">
  This action cannot be undone
</span>
```

### 8.2 Mobile Accessibility

```jsx
// Accessible TouchableOpacity
<TouchableOpacity
  accessible={true}
  accessibilityLabel="Delete account"
  accessibilityHint="This action cannot be undone"
  accessibilityRole="button"
  onPress={handleDelete}
>
  <Text>Delete</Text>
</TouchableOpacity>
```

---

*Document Version: 1.0*  
*Last Updated: 2026-08-13*  
*Author: SmartFin Development Team*
